#!/bin/sh
cd "$(dirname "$0")"
python3 -m pip install --upgrade pyinstaller || exit 1
python3 -m PyInstaller --onefile --windowed --name TidepoolOS tidepool_os.py || exit 1
cp tidepool-os.img dist/
echo "Done. Your app is in the dist folder."

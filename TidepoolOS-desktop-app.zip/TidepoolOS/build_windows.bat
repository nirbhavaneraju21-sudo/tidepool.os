@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 echo Install Python from python.org first and tick "Add python.exe to PATH". & pause & exit /b 1
python -m pip install --upgrade pyinstaller
if errorlevel 1 echo Could not install PyInstaller. Check your internet. & pause & exit /b 1
python -m PyInstaller --onefile --windowed --name TidepoolOS tidepool_os.py
if errorlevel 1 echo Build failed. & pause & exit /b 1
copy /y tidepool-os.img dist\ >nul
echo.
echo Done. Your app is dist\TidepoolOS.exe
pause

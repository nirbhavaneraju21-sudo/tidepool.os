#!/usr/bin/env python3
"""
Tidepool OS desktop app

  python tidepool_os.py          Windows-style desktop (windows, taskbar, start menu, apps).
                                 If QEMU is installed and tidepool-os.img sits next to this
                                 file, it boots the real OS image instead.
  python tidepool_os.py --sim    skip QEMU and open the desktop
  python tidepool_os.py --real   always use QEMU (exits with a message if missing)
  python tidepool_os.py --shell  only the classic blue shell screen

The shell here imitates the real OS image's shell. It is not the kernel itself.
"""
import datetime
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time

# When packaged as an .exe/.app, look for the OS image next to the program itself.
HERE = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
IMG = os.path.join(HERE, "tidepool-os.img")
CONF = os.path.join(os.path.expanduser("~"), ".tidepool_os.json")
START = time.time()

# The 16 VGA text-mode colours, index 0-15.
VGA = ["#000000", "#0000AA", "#00AA00", "#00AAAA", "#AA0000", "#AA00AA", "#AA5500", "#AAAAAA",
       "#555555", "#5555FF", "#55FF55", "#55FFFF", "#FF5555", "#FF55FF", "#FFFF55", "#FFFFFF"]

BANNER = ("Tidepool OS 1.1\nInterrupts, timer and memory manager are running.\n"
          "Type help to see what you can do.\n\n")
HELP = """help      show this list
clear     clear the screen
echo ...  print text
time      show date and time
uptime    time since boot
sleep N   wait N seconds
cpu       show CPU vendor
mem       RAM and free pages (simulated here)
crash     trigger a CPU exception (panic screen)
color XY  set colours (e.g. color 1f, color 0a)
colors    show the colour palette
about     about this OS
reboot    restart the computer
shutdown  power off
"""


# ---------------------------------------------------------------- shell logic
def hexval(c):
    try:
        return int(c, 16)
    except ValueError:
        return -1


def cpu_vendor():
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("vendor_id"):
                    return line.split(":")[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine() or "unknown"


def execute(line):
    """Run one command. Returns a list of (kind, value) events for the screen."""
    line = line.strip()
    if not line:
        return []
    cmd, _, arg = line.partition(" ")
    arg = arg.strip()
    if cmd == "help":
        return [("out", HELP)]
    if cmd == "clear":
        return [("clear", None)]
    if cmd == "echo":
        return [("out", arg + "\n")]
    if cmd in ("time", "date"):
        now = datetime.datetime.now().strftime("%H:%M:%S  %d/%m/%Y")
        return [("out", now + "  (hardware clock)\n")]
    if cmd == "cpu":
        return [("out", "CPU vendor: " + cpu_vendor() + "\n")]
    if cmd == "uptime":
        s = int(time.time() - START)
        return [("out", "%dh %dm %ds  (%d ticks)\n" % (s // 3600, s // 60 % 60, s % 60, s * 100))]
    if cmd == "sleep":
        n = min(int(arg), 3600) if arg.isdigit() else 0
        return [("sleep", n)] if n else []
    if cmd == "mem":
        return [("out", "Usable RAM (BIOS map): 127 MB (simulated)\n"
                        "Free pages: 32000 of 32512 (4 KB each, 1-128 MB range)\n")]
    if cmd == "crash":
        return [("panic", "Divide error (int 0, error 0x00000000) at EIP 0x00010a42")]
    if cmd == "colors":
        return [("palette", None)]
    if cmd == "color":
        hi = hexval(arg[0]) if arg else -1
        lo = hexval(arg[1]) if len(arg) > 1 else -1
        if hi < 0:
            return [("out", "usage: color <fg> or color <bg><fg>  (hex digits 0-f, e.g. color 1f)\n")]
        return [("color", (None, hi) if lo < 0 else (hi, lo))]
    if cmd == "about":
        return [("out", "Tidepool OS 1.1: a tiny 32-bit x86 operating system.\n"
                        "BIOS boot, interrupts, timer, memory manager, keyboard, shell.\n")]
    if cmd == "reboot":
        return [("reboot", None)]
    if cmd in ("shutdown", "halt"):
        return [("out", "Shutting down...\n"),
                ("out", "It is now safe to turn off your computer.\n"),
                ("quit", None)]
    return [("out", cmd + ": command not found (try help)\n")]


# ---------------------------------------------------------------- shell screen widget
def make_shell(tk, parent, quit_cb, cols=80, rows=25):
    """Builds the blue Tidepool shell as a Text widget (caller packs it)."""
    state = {"bg": 1, "fg": 15, "alive": True, "busy": False, "halted": False}
    buf = []
    t = tk.Text(parent, width=cols, height=rows, font=("Courier New", 12), bd=0, padx=8, pady=6,
                bg=VGA[1], fg=VGA[15], insertbackground=VGA[15], wrap="char", cursor="arrow")
    t.tag_configure("prompt", foreground=VGA[14])
    t.tag_configure("panic", background=VGA[4], foreground="#FFFFFF")
    for i in range(16):
        t.tag_configure("c%d" % i, background=VGA[i], foreground="#FFFFFF" if i < 8 else "#000000")

    def out(s, tag=None):
        t.insert("end", s, tag)
        t.see("end")

    def prompt():
        out("tidepool> ", "prompt")

    def boot():
        t.delete("1.0", "end")
        out(BANNER)
        prompt()

    def apply(kind, val):
        """Handle one event. Returns True if a new prompt should NOT be drawn."""
        if kind == "out":
            out(val)
        elif kind == "clear":
            t.delete("1.0", "end")
        elif kind == "palette":
            for i in range(16):
                out(" %x " % i, "c%d" % i)
            out("\n")
        elif kind == "color":
            bg, fg = val
            if bg is not None:
                state["bg"] = bg
            state["fg"] = fg
            t.config(bg=VGA[state["bg"]], fg=VGA[fg], insertbackground=VGA[fg])
        elif kind == "reboot":
            boot()
            return True
        elif kind == "sleep":
            state["busy"] = True

            def done():
                state["busy"] = False
                prompt()

            t.after(val * 1000, done)
            return True
        elif kind == "panic":
            out("\n*** KERNEL PANIC: " + val + " ***\nSystem halted. Press Enter to reboot.\n", "panic")
            state["halted"] = True
            return True
        elif kind == "quit":
            state["alive"] = False
            quit_cb()
        return False

    def on_key(e):
        if not state["alive"] or state["busy"]:
            return "break"
        if state["halted"]:
            if e.keysym in ("Return", "KP_Enter"):
                state["halted"] = False
                boot()
            return "break"
        if e.keysym in ("Return", "KP_Enter"):
            line = "".join(buf)
            buf.clear()
            out("\n")
            skip = False
            for kind, val in execute(line):
                skip = apply(kind, val) or skip
            if state["alive"] and not skip:
                prompt()
        elif e.keysym == "BackSpace":
            if buf:
                buf.pop()
                t.delete("end-2c", "end-1c")
        elif e.char and e.char.isprintable() and len(buf) < 79:
            buf.append(e.char)
            out(e.char)
        return "break"

    t.bind("<Key>", on_key)
    t.bind("<Button-1>", lambda e: t.focus_set())
    boot()
    return t


def run_shell_screen(tk, root):
    root.title("Tidepool OS")
    root.resizable(False, False)
    t = make_shell(tk, root, lambda: root.after(1200, root.destroy))
    t.pack()
    t.focus_set()
    root.mainloop()


# ---------------------------------------------------------------- windows-style desktop
def run_desktop(tk, root):
    from tkinter import colorchooser, filedialog, messagebox

    root.title("Tidepool OS")
    root.geometry("1000x640")
    root.minsize(640, 420)
    CH, CH2, INK, ACC, BAR, TB = "#f3f0e8", "#dedacd", "#17222a", "#1f8a80", "#0a1a21", "#1c3340"
    WALLS = ["#0f2a35", "#25264f", "#10303a", "#2d3b2f", "#3b2a3f"]
    conf = {"wall": WALLS[0]}
    try:
        with open(CONF) as f:
            conf.update(json.load(f))
    except (OSError, ValueError, TypeError):
        pass

    bar = tk.Frame(root, bg=BAR, height=42)
    bar.pack(side="bottom", fill="x")
    bar.pack_propagate(False)
    desk = tk.Frame(root, bg=conf["wall"])
    desk.pack(fill="both", expand=True)
    tasks = tk.Frame(bar, bg=BAR)
    wins, frames, icons = [], {}, []

    # ---- window manager
    class Win:
        def __init__(self, title, build, w, h):
            n = len(wins) % 8
            self.title, self.max, self.hidden, self.active, self.alive = title, False, False, False, True
            self.g = dict(x=70 + n * 28, y=20 + n * 28, width=w, height=h, relwidth=0, relheight=0)
            self.normal = None
            self.f = tk.Frame(desk, bg=CH, bd=1, relief="solid")
            self.tb = tk.Frame(self.f, bg=CH2)
            self.tb.pack(fill="x")
            self.lbl = tk.Label(self.tb, text=title, bg=CH2, fg=INK, anchor="w", font=("Segoe UI", 10, "bold"))
            self.lbl.pack(side="left", fill="x", expand=True, padx=8, pady=4)
            self.labels = [self.lbl]
            for txt, cmd in (("\u2715", self.close), ("\u25a1", self.toggle_max), ("\u2014", self.minimize)):
                b = tk.Label(self.tb, text=txt, width=5, bg=CH2, fg=INK, cursor="hand2")
                b.pack(side="right", fill="y")
                b.bind("<Button-1>", lambda e, c=cmd: c())
                self.labels.append(b)
            self.body = tk.Frame(self.f, bg=CH)
            self.body.pack(fill="both", expand=True)
            grip = tk.Label(self.f, text="\u25e2", bg=CH, fg="#888888", cursor="size_nw_se")
            grip.place(relx=1, rely=1, anchor="se")
            self.btn = tk.Button(tasks, text=title, command=self.task_click, bd=0, relief="flat", bg=TB,
                                 fg="white", activebackground=ACC, activeforeground="white", padx=10, width=14)
            self.btn.pack(side="left", padx=2, pady=5)
            for part in (self.tb, self.lbl):
                part.bind("<ButtonPress-1>", self.press)
                part.bind("<B1-Motion>", self.drag)
                part.bind("<Double-Button-1>", lambda e: self.toggle_max())
            grip.bind("<ButtonPress-1>", lambda e: setattr(self, "rs", (e.x_root, e.y_root, self.g["width"], self.g["height"])))
            grip.bind("<B1-Motion>", self.resize)
            wins.append(self)
            frames[str(self.f)] = self
            self.put()
            build(self)
            self.activate()

        def put(self):
            self.f.place(**self.g)

        def press(self, e):
            self.d = (e.x_root - self.g["x"], e.y_root - self.g["y"])
            self.activate()

        def drag(self, e):
            if self.max or not hasattr(self, "d"):
                return
            self.g["x"] = max(80 - self.g["width"], min(e.x_root - self.d[0], desk.winfo_width() - 80))
            self.g["y"] = max(0, min(e.y_root - self.d[1], desk.winfo_height() - 30))
            self.put()

        def resize(self, e):
            if self.max or not hasattr(self, "rs"):
                return
            self.g["width"] = max(240, self.rs[2] + e.x_root - self.rs[0])
            self.g["height"] = max(140, self.rs[3] + e.y_root - self.rs[1])
            self.put()

        def paint(self, active):
            self.active = active and not self.hidden
            bg, fg = (ACC, "white") if self.active else (CH2, INK)
            self.tb.config(bg=bg)
            for p in self.labels:
                p.config(bg=bg, fg=fg)
            self.btn.config(bg=ACC if self.active else TB)

        def activate(self):
            if self.hidden:
                return
            for x in wins:
                x.paint(x is self)
            self.f.lift()

        def set_title(self, t):
            self.title = t
            self.lbl.config(text=t)
            self.btn.config(text=t)

        def minimize(self):
            self.hidden = True
            self.f.place_forget()
            self.paint(False)

        def task_click(self):
            if self.hidden:
                self.hidden = False
                self.put()
                self.activate()
            elif self.active:
                self.minimize()
            else:
                self.activate()

        def toggle_max(self):
            if not self.max:
                self.normal = dict(self.g)
                self.g = dict(x=0, y=0, width=0, height=0, relwidth=1, relheight=1)
            else:
                self.g = self.normal
            self.max = not self.max
            self.put()

        def close(self):
            self.alive = False
            wins.remove(self)
            frames.pop(str(self.f), None)
            self.f.destroy()
            self.btn.destroy()

    def on_click(e):
        wdg = e.widget
        while wdg is not None and not isinstance(wdg, str):
            w = frames.get(str(wdg))
            if w:
                w.activate()
                return
            wdg = getattr(wdg, "master", None)

    root.bind_all("<Button-1>", on_click, add="+")

    def save_conf():
        try:
            with open(CONF, "w") as f:
                json.dump(conf, f)
        except OSError:
            pass

    def set_wall(c):
        conf["wall"] = c
        desk.config(bg=c)
        for frame, name in icons:
            frame.config(bg=c)
            name.config(bg=c)
        save_conf()

    # ---- apps
    def app_notepad(w, path=None, text=""):
        state = {"path": path}
        tools = tk.Frame(w.body, bg=CH)
        tools.pack(fill="x")
        t = tk.Text(w.body, undo=True, wrap="word", font=("Consolas", 11), bd=0, padx=8, pady=6)
        sb = tk.Scrollbar(w.body, command=t.yview)
        t.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        t.insert("1.0", text)
        if path:
            w.set_title("Notepad - " + os.path.basename(path))

        def open_():
            p = filedialog.askopenfilename(parent=root)
            if not p:
                return
            try:
                with open(p, encoding="utf-8", errors="replace") as f:
                    data = f.read()
            except OSError as ex:
                messagebox.showerror("Notepad", str(ex), parent=root)
                return
            t.delete("1.0", "end")
            t.insert("1.0", data)
            state["path"] = p
            w.set_title("Notepad - " + os.path.basename(p))

        def save(as_=False):
            p = state["path"]
            if as_ or not p:
                p = filedialog.asksaveasfilename(parent=root, defaultextension=".txt",
                                                 filetypes=[("Text", "*.txt"), ("All files", "*.*")])
            if not p:
                return
            try:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(t.get("1.0", "end-1c"))
            except OSError as ex:
                messagebox.showerror("Notepad", str(ex), parent=root)
                return
            state["path"] = p
            w.set_title("Notepad - " + os.path.basename(p))

        for label, cmd in (("Open", open_), ("Save", save), ("Save as", lambda: save(True))):
            tk.Button(tools, text=label, command=cmd, bd=0, bg=CH2, padx=10).pack(side="left", padx=2, pady=3)
        t.bind("<Control-s>", lambda e: (save(), "break")[1])

    def app_calc(w):
        ex = {"s": ""}
        disp = tk.Label(w.body, text="0", anchor="e", font=("Segoe UI", 22), bg="white", fg=INK, padx=10, pady=8)
        disp.pack(fill="x", padx=8, pady=8)
        g = tk.Frame(w.body, bg=CH)
        g.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        def press(k):
            s = "" if ex["s"] == "Error" else ex["s"]
            if k == "C":
                s = ""
            elif k == "\u232b":
                s = s[:-1]
            elif k == "=":
                if s:
                    try:
                        if not re.fullmatch(r"[\d+\-*/.() ]+", s) or "**" in s:
                            raise ValueError
                        v = eval(s, {"__builtins__": {}}, {})
                        if not isinstance(v, (int, float)):
                            raise ValueError
                        s = str(v) if isinstance(v, int) else ("%.9f" % v).rstrip("0").rstrip(".")
                    except Exception:
                        s = "Error"
            else:
                s += k
            ex["s"] = s
            disp.config(text=s or "0")

        keys = "C ( ) / 7 8 9 * 4 5 6 - 1 2 3 + 0 . \u232b =".split()
        for i, k in enumerate(keys):
            op = k in "/*-+="
            tk.Button(g, text=k, command=lambda k=k: press(k), font=("Segoe UI", 13), bd=0,
                      bg="#f4b942" if op else CH2).grid(row=i // 4, column=i % 4, sticky="nsew", padx=2, pady=2)
        for r in range(5):
            g.rowconfigure(r, weight=1)
        for c in range(4):
            g.columnconfigure(c, weight=1, uniform="k")

    def app_explorer(w, path=None):
        cur = {"p": path or os.path.expanduser("~")}
        head = tk.Label(w.body, anchor="w", bg=CH, fg=INK, font=("Segoe UI", 9))
        head.pack(fill="x", padx=8, pady=4)
        box = tk.Frame(w.body, bg=CH)
        box.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        lb = tk.Listbox(box, font=("Segoe UI", 10), activestyle="none", bd=0)
        sb = tk.Scrollbar(box, command=lb.yview)
        lb.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        lb.pack(fill="both", expand=True)

        def load(p):
            try:
                names = sorted(os.listdir(p), key=lambda n: (not os.path.isdir(os.path.join(p, n)), n.lower()))
            except OSError as ex:
                messagebox.showerror("Explorer", str(ex), parent=root)
                return
            cur["p"] = p
            head.config(text=p)
            w.set_title("Explorer - " + (os.path.basename(p) or p))
            lb.delete(0, "end")
            lb.insert("end", "\u25b2  ..")
            for n in names:
                lb.insert("end", ("\u25b8  " if os.path.isdir(os.path.join(p, n)) else "\u00b7  ") + n)

        def open_sel(e=None):
            i = lb.curselection()
            if not i:
                return
            n = lb.get(i[0])[3:]
            p = os.path.dirname(cur["p"]) if n == ".." else os.path.join(cur["p"], n)
            if os.path.isdir(p):
                load(p)
                return
            try:
                with open(p, "rb") as f:
                    data = f.read(1000001)
                if len(data) <= 1000000 and b"\0" not in data:
                    launch("notepad", path=p, text=data.decode("utf-8", "replace"))
                elif hasattr(os, "startfile"):
                    os.startfile(p)
                else:
                    subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", p])
            except OSError as ex:
                messagebox.showerror("Explorer", str(ex), parent=root)

        lb.bind("<Double-Button-1>", open_sel)
        lb.bind("<Return>", open_sel)
        load(cur["p"])

    def app_terminal(w):
        t = make_shell(tk, w.body, lambda: root.after(1200, root.destroy), 44, 12)
        t.pack(fill="both", expand=True)
        t.focus_set()

    def app_paint(w):
        st = {"c": "#000000", "s": 4, "last": None}
        tools = tk.Frame(w.body, bg=CH)
        tools.pack(fill="x", padx=4, pady=4)
        for c in ("#000000", "#e53935", "#fb8c00", "#fdd835", "#43a047", "#1e88e5", "#8e24aa", "#ffffff"):
            tk.Button(tools, bg=c, width=2, bd=1, command=lambda c=c: st.update(c=c)).pack(side="left", padx=1)

        def more():
            c = colorchooser.askcolor(parent=root)[1]
            if c:
                st["c"] = c

        tk.Button(tools, text="More...", command=more, bd=0, bg=CH2).pack(side="left", padx=6)
        sz = tk.Scale(tools, from_=1, to=30, orient="horizontal", showvalue=False, length=90, bg=CH, bd=0,
                      highlightthickness=0, command=lambda v: st.update(s=int(float(v))))
        sz.set(4)
        sz.pack(side="left")
        cv = tk.Canvas(w.body, bg="white", highlightthickness=0, cursor="crosshair")
        tk.Button(tools, text="Clear", command=lambda: cv.delete("all"), bd=0, bg=CH2).pack(side="right")
        cv.pack(fill="both", expand=True)

        def down(e):
            st["last"] = (e.x, e.y)
            r = st["s"] / 2
            cv.create_oval(e.x - r, e.y - r, e.x + r, e.y + r, fill=st["c"], outline=st["c"])

        def move(e):
            if st["last"]:
                cv.create_line(st["last"][0], st["last"][1], e.x, e.y, fill=st["c"], width=st["s"],
                               capstyle="round")
                st["last"] = (e.x, e.y)

        cv.bind("<ButtonPress-1>", down)
        cv.bind("<B1-Motion>", move)
        cv.bind("<ButtonRelease-1>", lambda e: st.update(last=None))

    def app_tasks(w):
        lb = tk.Listbox(w.body, font=("Segoe UI", 10), activestyle="none")
        lb.pack(fill="both", expand=True, padx=8, pady=8)
        info = tk.Label(w.body, bg=CH, fg=INK, anchor="w")
        info.pack(fill="x", padx=8)
        snap = []

        def end():
            i = lb.curselection()
            if i and i[0] < len(snap):
                snap[i[0]].close()

        tk.Button(w.body, text="End task", command=end, bd=0, bg=CH2, padx=12).pack(anchor="e", padx=8, pady=8)

        def refresh():
            if not w.alive:
                return
            titles = [x.title for x in wins]
            if titles != [x.title for x in snap]:
                snap[:] = list(wins)
                lb.delete(0, "end")
                for x in snap:
                    lb.insert("end", x.title)
            up = int(time.time() - START)
            info.config(text="Running apps: %d    Uptime: %02d:%02d" % (len(wins), up // 60, up % 60))
            root.after(1000, refresh)

        refresh()

    def app_settings(w):
        tk.Label(w.body, text="Wallpaper", bg=CH, fg=INK, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(12, 4))
        row = tk.Frame(w.body, bg=CH)
        row.pack(anchor="w", padx=12)
        for c in WALLS:
            tk.Button(row, bg=c, width=4, bd=1, command=lambda c=c: set_wall(c)).pack(side="left", padx=2)

        def custom():
            c = colorchooser.askcolor(parent=root)[1]
            if c:
                set_wall(c)

        tk.Button(row, text="Custom...", command=custom, bd=0, bg=CH2).pack(side="left", padx=8)
        tk.Label(w.body, text="About", bg=CH, fg=INK, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(16, 4))
        tk.Label(w.body, text="Tidepool OS desktop 1.0\nPython %s on %s" % (platform.python_version(), platform.system()),
                 bg=CH, fg=INK, justify="left").pack(anchor="w", padx=12)

    APPS = {
        "notepad": ("Notepad", "\u270e", "#e8a33d", 460, 340, app_notepad),
        "calc": ("Calculator", "\u25a6", "#2a9d8f", 280, 390, app_calc),
        "explorer": ("Explorer", "\u25a3", "#3b82c4", 480, 360, app_explorer),
        "terminal": ("Terminal", ">_", "#333a40", 520, 320, app_terminal),
        "paint": ("Paint", "\u2710", "#c2467a", 520, 400, app_paint),
        "tasks": ("Task Manager", "\u2630", "#6b5bb5", 340, 320, app_tasks),
        "settings": ("Settings", "\u2699", "#5f6b73", 340, 240, app_settings),
    }

    def launch(name, **kw):
        title, _glyph, _color, w, h, fn = APPS[name]
        Win(title, lambda win: fn(win, **kw), w, h)

    # ---- desktop icons
    for idx, (name, (title, glyph, color, _w, _h, _fn)) in enumerate(APPS.items()):
        frame = tk.Frame(desk, bg=conf["wall"])
        frame.place(x=14 + (idx // 6) * 92, y=12 + (idx % 6) * 92, width=84, height=86)
        tile = tk.Label(frame, text=glyph, bg=color, fg="white", font=("Segoe UI Symbol", 18), width=4)
        tile.pack(pady=(4, 2))
        nm = tk.Label(frame, text=title, bg=conf["wall"], fg="white", font=("Segoe UI", 9))
        nm.pack()
        icons.append((frame, nm))
        for part in (frame, tile, nm):
            part.bind("<Double-Button-1>", lambda e, n=name: launch(n))

    # ---- start menu and right-click menu
    def make_menu():
        return tk.Menu(root, tearoff=0, bg=BAR, fg="white", activebackground=ACC, activeforeground="white",
                       bd=0, font=("Segoe UI", 10))

    menu = make_menu()
    for name, (title, glyph, _c, _w, _h, _fn) in APPS.items():
        menu.add_command(label="  %s   %s" % (glyph, title), command=lambda n=name: launch(n))
    menu.add_separator()
    menu.add_command(label="  Shut down", command=root.destroy)

    ctx = make_menu()
    ctx.add_command(label="  New Notepad", command=lambda: launch("notepad"))
    ctx.add_command(label="  Terminal", command=lambda: launch("terminal"))
    ctx.add_command(label="  Settings", command=lambda: launch("settings"))

    def popup(m, x, y):
        try:
            m.tk_popup(x, y)
        finally:
            m.grab_release()

    start = tk.Button(bar, text="\u229e  Start", command=lambda: popup(menu, start.winfo_rootx(),
                      start.winfo_rooty() - menu.winfo_reqheight()), bd=0, bg=ACC, fg="white",
                      activebackground="#25a89c", activeforeground="white", font=("Segoe UI", 10, "bold"), padx=14)
    start.pack(side="left", fill="y")
    clock = tk.Label(bar, bg=BAR, fg="white", font=("Segoe UI", 8), padx=10)
    clock.pack(side="right")
    tasks.pack(side="left", fill="both", expand=True, padx=6)
    for ev in ("<Button-3>", "<Button-2>"):
        desk.bind(ev, lambda e: popup(ctx, e.x_root, e.y_root))

    def tick():
        clock.config(text=datetime.datetime.now().strftime("%H:%M\n%d/%m/%Y"))
        root.after(1000, tick)

    tick()
    launch("terminal")
    root.mainloop()


# ---------------------------------------------------------------- terminal version
def run_terminal():
    if os.name == "nt":
        os.system("")  # enables ANSI colours in the Windows console
    ansi = [0, 4, 2, 6, 1, 5, 3, 7]  # VGA colour order -> ANSI colour order

    def sgr(bg, fg):
        b = 40 + ansi[bg] if bg < 8 else 100 + ansi[bg - 8]
        f = 30 + ansi[fg] if fg < 8 else 90 + ansi[fg - 8]
        return "\x1b[%d;%dm" % (b, f)

    bg, fg = 1, 15

    def cls():
        sys.stdout.write(sgr(bg, fg) + "\x1b[2J\x1b[H")

    cls()
    sys.stdout.write(BANNER)
    while True:
        try:
            line = input(sgr(bg, 14) + "tidepool> " + sgr(bg, fg))
        except (EOFError, KeyboardInterrupt):
            break
        for kind, val in execute(line):
            if kind == "out":
                sys.stdout.write(val)
            elif kind == "clear":
                cls()
            elif kind == "palette":
                for i in range(16):
                    sys.stdout.write(sgr(i, 15 if i < 8 else 0) + " %x " % i)
                sys.stdout.write(sgr(bg, fg) + "\n")
            elif kind == "color":
                if val[0] is not None:
                    bg = val[0]
                fg = val[1]
                cls()
            elif kind == "reboot":
                cls()
                sys.stdout.write(BANNER)
            elif kind == "sleep":
                time.sleep(val)
            elif kind == "panic":
                sys.stdout.write("\n" + sgr(4, 15) + "*** KERNEL PANIC: " + val + " ***" + sgr(bg, fg)
                                 + "\nSystem halted.\n")
                try:
                    input("Press Enter to reboot...")
                except (EOFError, KeyboardInterrupt):
                    break
                cls()
                sys.stdout.write(BANNER)
            elif kind == "quit":
                sys.stdout.write("\x1b[0m\n")
                return
    sys.stdout.write("\x1b[0m\n")


# ---------------------------------------------------------------- entry point
def main():
    args = sys.argv[1:]
    if "--sim" not in args and "--shell" not in args:
        qemu = shutil.which("qemu-system-i386") or shutil.which("qemu-system-x86_64")
        if qemu and os.path.exists(IMG):
            subprocess.run([qemu, "-drive", "format=raw,file=" + IMG])
            return
        if "--real" in args:
            sys.exit("Couldn't start the real OS. Install QEMU and keep tidepool-os.img "
                     "next to this file.")
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        run_terminal()
    else:
        if "--shell" in args:
            run_shell_screen(tk, root)
        else:
            run_desktop(tk, root)


if __name__ == "__main__":
    main()

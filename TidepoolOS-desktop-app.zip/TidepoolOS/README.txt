Tidepool OS desktop app

WINDOWS
  1. Install Python from python.org (tick "Add python.exe to PATH").
  2. Unzip this folder, then double-click build_windows.bat.
  3. When it finishes, run dist\TidepoolOS.exe.

MAC / LINUX
  Run ./build_mac_linux.sh in a terminal, then open the app from the dist folder.

NO PC TO BUILD ON? BUILD IT IN THE CLOUD (works from a phone browser)
  1. Make a free account at github.com and create a new repository.
  2. Add file > Upload files: upload tidepool_os.py and tidepool-os.img.
  3. Add file > Create new file. Name it  .github/workflows/build.yml
     (typing the slashes creates the folders) and paste in the text of
     github-build.yml.txt. Commit it.
  4. Open the Actions tab and wait for "Build Windows app" to finish (a few
     minutes). Open the run and download the TidepoolOS-Windows artifact.
     Unzip it: TidepoolOS.exe is your app (keep tidepool-os.img beside it).

No build needed? With Python installed you can also just run:
  python tidepool_os.py

What the app does
  It opens a Windows-style desktop: movable, resizable windows (minimize,
  maximize, close), a taskbar with a clock, a Start menu, desktop icons
  (double-click to open) and a right-click menu.

  Built-in apps
    Notepad        open and save text files
    Calculator
    Explorer       browse the real folders and files on your PC
    Terminal       the Tidepool OS shell (help, time, uptime, sleep, mem, crash, ...)
    Paint          draw with colours and brush sizes
    Task Manager   see open apps and end them
    Settings       change the wallpaper

  If QEMU is installed and tidepool-os.img is next to the app, it boots the
  real OS image in QEMU instead. Options:
    --sim     skip QEMU and open the desktop
    --real    always use QEMU
    --shell   only the classic blue shell screen

Windows may show a "Windows protected your PC" warning for unsigned apps you
build yourself: choose More info, then Run anyway.
